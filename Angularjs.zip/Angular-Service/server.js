const express = require('express');
const bodyParser = require('body-parser');
var cors = require('cors');
const app = express();

app.use(bodyParser.json());
app.use(
    cors({ origin: ["http://127.0.0.1:8080", "http://127.0.0.1:58596"] })
);
let users = []; 

// Register endpoint
app.post('/api/register', (req, res) => {
    const { name, email, password, gender, phoneNumber } = req.body;
    if (users.find(user => user.email === email)) {
        return res.status(400).send('User already exists');
    }
    users.push({ name, email, password, gender, phoneNumber });
    res.status(200).send('User registered');
});

// Login endpoint
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(user => user.email === email && user.password === password);
    if (!user) {
        return res.status(401).send('Invalid credentials');
    }
    res.status(200).send({ user: { email: user.email } });
});

// Update user endpoint
app.put('/api/putUser', (req, res) => {
    const { email } = req.body;
    const userIndex = users.findIndex(user => user.email === email);

    if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...req.body };
        res.json(users[userIndex]);
    } else {
        res.status(404).json({ message: 'User not found' });
    }
});
//delete user endpoint
app.post('/api/deleteUser', (req, res) => {
    const { email } = req.body;
    const userIndex = users.findIndex(user => user.email === email);
    if (userIndex === -1) {
        return res.status(404).send('User not found');
    }
    users.splice(userIndex, 1);
    res.status(200).send({ users: users });
});

// Get user endpoint
app.get('/api/getUser', (req, res) => {

    res.status(200).send({ users: users });
});

app.listen(8080, () => {
    console.log('Server running on http://localhost:8080');
});


