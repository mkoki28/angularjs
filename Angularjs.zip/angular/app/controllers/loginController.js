app.controller('LogInController', function ($scope, $http, $window) {
    $scope.header = 'Login';
    $scope.isAuthenticated = false;
    $scope.user = {
        email: '',
        password: ''
    };

    $scope.registerDatas = [];
    $scope.registerData = {};
    // Replace with your actual API endpoint
    var apiUrl = 'http://localhost:8080/api/getUser';

    $http.get(apiUrl)
        .then(function (response) {
            $scope.registerDatas = response.data.users;
        })
        .catch(function (error) {
            console.error('Error fetching user data:', error);
        });
    $scope.deleteUser = function (user) {
        $http.post('http://localhost:8080/api/deleteUser', user)
            .then(function (response) {
                $scope.registerDatas = response.data.users;
            })
            .catch(function (error) {
                console.error('Error deleting user:', error);
            });
    };
    $http.get(apiUrl)
        .then(function (response) {
            $scope.user = response.data;
        })
        .catch(function (error) {
            console.error('Error fetching user data:', error);
        });
    // Enable edit mode
    $scope.editUser = function (registerData) {
        registerData.editMode = true;
        registerData.originalData = angular.copy(registerData);
    };
    // Update user datas
    
    $scope.updateUser = function (user) {
        user.editMode = false;
        $http.put('http://localhost:8080/api/putUser', user)
            .then(function (response) {
                alert('User updated successfully!');
               
                $window.location.href = '/display.html';
            })
            .catch(function (error) {
                user.editMode = true;
                alert.error('Error updating user:', error);
            });
    };
    
    // Define the controller
    $scope.today = function () {
        // Datepicker settings
        $scope.user.dob = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.user.dob = null;
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.open = function () {
        $scope.popup.opened = true;
    };

    $scope.popup = {
        opened: false
    };

    // Login function
    $scope.login = function () {
        $http.post('http://localhost:8080/api/login', $scope.user)
            .then(function (response) {
                $scope.isAuthenticated = true;
                $scope.user = response.data;
                alert('Login successful!');
                $window.location.href = '/register.html';
            }, function (error) {
                alert(error);
                alert('Login failed!');
            });
    };

    // Register function
    $scope.register = function () {
        $http.post('http://localhost:8080/api/register', $scope.registerData)
            .then(function (response) {
                $scope.isAuthenticated = true;
                alert('Registration successful!');
                $scope.registerData = {
                    name: '',
                    email: '',
                    password: '',
                    gender: '',
                    phoneNumber: ''
                };
            }, function (error) {
                alert(error);
                alert('Registration failed!');
            });
    };
});